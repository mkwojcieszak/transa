<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/admin' => [[['_route' => 'admin.panel', '_controller' => 'App\\Controller\\AdminController::index'], null, null, null, true, false, null]],
        '/admin/trasy' => [[['_route' => 'admin.trasy', '_controller' => 'App\\Controller\\AdminController::trasy'], null, null, null, false, false, null]],
        '/admin/nowa_trasa' => [[['_route' => 'admin.nowa_trasa', '_controller' => 'App\\Controller\\AdminController::nowaTrasa'], null, null, null, false, false, null]],
        '/admin/posty' => [[['_route' => 'admin.posty', '_controller' => 'App\\Controller\\AdminController::posty'], null, null, null, false, false, null]],
        '/admin/nowy_post' => [[['_route' => 'admin.nowy_post', '_controller' => 'App\\Controller\\AdminController::nowyPost'], null, null, null, false, false, null]],
        '/' => [[['_route' => 'main', '_controller' => 'App\\Controller\\MainController::index'], null, null, null, false, false, null]],
        '/login' => [[['_route' => 'app_login', '_controller' => 'App\\Controller\\SecurityController::login'], null, null, null, false, false, null]],
        '/rejestracja' => [[['_route' => 'register', '_controller' => 'App\\Controller\\SecurityController::register'], null, null, null, false, false, null]],
        '/logout' => [[['_route' => 'app_logout', '_controller' => 'App\\Controller\\SecurityController::logout'], null, null, null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/_error/(\\d+)(?:\\.([^/]++))?(*:35)'
                .'|/admin/(?'
                    .'|trasa/([^/]++)(*:66)'
                    .'|kursy/([^/]++)(*:87)'
                    .'|nowy_kurs/([^/]++)(*:112)'
                    .'|edytuj_kurs/([^/]++)(*:140)'
                    .'|post/([^/]++)(*:161)'
                .')'
            .')/?$}sDu',
    ],
    [ // $dynamicRoutes
        35 => [[['_route' => '_preview_error', '_controller' => 'error_controller::preview', '_format' => 'html'], ['code', '_format'], null, null, false, true, null]],
        66 => [[['_route' => 'admin.trasa', '_controller' => 'App\\Controller\\AdminController::trasa'], ['id'], null, null, false, true, null]],
        87 => [[['_route' => 'admin.kursy', '_controller' => 'App\\Controller\\AdminController::kursy'], ['id'], null, null, false, true, null]],
        112 => [[['_route' => 'admin.nowy_kurs', '_controller' => 'App\\Controller\\AdminController::nowyKurs'], ['id'], null, null, false, true, null]],
        140 => [[['_route' => 'admin.edytuj_kurs', '_controller' => 'App\\Controller\\AdminController::edytujKurs'], ['id'], null, null, false, true, null]],
        161 => [
            [['_route' => 'admin.post', '_controller' => 'App\\Controller\\AdminController::displayPost'], ['id'], null, null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
