<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* main/index.html.twig */
class __TwigTemplate_2b6575cbd5a36c95ba21249ea18580f9bbebcb58ae730b256b3dc0bc175d05b8 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "front_base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "main/index.html.twig"));

        $this->parent = $this->loadTemplate("front_base.html.twig", "main/index.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "Transa";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 5
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "<div class=\"site\">
<div class='bg'>




<div class='main-logo'><h1>Transa</h1><h4>Przewozy pasażerskie</h4></div>





<ul class='nav-list'>
    <li>
        <a href='#' class='nav-link'>
            <div class=\"icon\">
                <i class='fa fa-home' aria-hidden='true'></i>
                <i class='fa fa-home' aria-hidden='true'></i>
            </div>
            <div class=\"name\">
                <p>Nowości</p>
                <p>Nowości</p>
            </div>
        </a>
    </li>
    <li>
        <a href='#' class='nav-link'>
            <div class=\"icon\">
                <i class='fa fa-bus' aria-hidden='true'></i>
                <i class='fa fa-bus' aria-hidden='true'></i>
            </div>
            <div class=\"name\">
                <p>Oferta</p>
                <p>Oferta</p>
            </div>
        </a>
    </li>
    <li>
        <a href='#' class='nav-link'>
            <div class=\"icon\">
                <i class='fa fa-road' aria-hidden='true'></i>
                <i class='fa fa-road' aria-hidden='true'></i>
            </div>
            <div class=\"name\">
                <p>Rozkłady</p>
                <p>Rozkłady</p>
            </div>
        </a>
    </li>
    <li>
        <a href='#' class='nav-link'>
            <div class=\"icon\">
                <i class='fa fa-envelope' aria-hidden='true'></i>
                <i class='fa fa-envelope' aria-hidden='true'></i>
            </div>
            <div class=\"name\">
                <p>Kontakt</p>
                <p>Kontakt</p>
            </div>
        </a>
    </li>
    <li>
        <a href='#' class='nav-link'>
            <div class=\"icon\">
                <i class='fa fa-file' aria-hidden='true'></i>
                <i class='fa fa-file' aria-hidden='true'></i>
            </div>
            <div class=\"name\">
                <p>Certyfikaty</p>
                <p>Certyfikaty</p>
            </div>
        </a>
    </li>
</ul>





    <div class='tab-wrapper'>



        <div class='tab hidden' id='news'><div class='page-container'>
        <div class='news-wrapper'>
            ";
        // line 91
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["newsy"]) || array_key_exists("newsy", $context) ? $context["newsy"] : (function () { throw new RuntimeError('Variable "newsy" does not exist.', 91, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["news"]) {
            // line 92
            echo "                <div class='post'>
                    <h3>";
            // line 93
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["news"], "title", [], "any", false, false, false, 93), "html", null, true);
            echo "<span>";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["news"], "time", [], "any", false, false, false, 93), "html", null, true);
            echo "</span></h3>
                    <p>";
            // line 94
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["news"], "message", [], "any", false, false, false, 94), "html", null, true);
            echo "</p>
                </div>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['news'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 97
        echo "            </div>
        </div></div>



        <div class='tab hidden' id='oferta'><div class='page-container'>
            <h3>Wynajem pojazdów</h3>
                <p>Dysponujemy pojazdami <b>18, 20 i 55 miejscowymi</b>. Oferujemy wyjazdy dla grup na imprezy sportowe, kulturalne itp. Jeżeli potrzebują Państwo transportu osobowego, aby bezpiecznie i na czas dojechać tam gdzie zaplanowaliście to autobusy naszej firmy prowadzone przez doświadczonych i profesjonalnych kierowców, spełnią wszystkie Państwa oczekiwania.</p>
            <h3>Regularne linie</h3>
            <ul>
                <li>Szczecin - Stargard</li>
                <li>Szczecin - Pyrzyce</li>
                <li>Stargard - Pyrzyce</li>
                <li>Stargard - Brzezina</li>
                <li>Stargard - Żuków</li>
            </ul>
            <h3>Sprzedaż biletów autokarowych ONLINE</h3>
            <ul>
                <li>Przewody MIĘDZYNARODOWE</li>
                <li>Przewozy KRAJOWE</li>
                <li>Dowozy na LOTNISKO</li>
            </ul>
            <h3>Auto serwis</h3>
            <ul>
                <li>diagnostyka komputerowa</li>
                <li>mechanika pojazdowa</li>
                <li>obsługa:</li>
    filtry, oleje i płyny
                <li>zawieszenia pojazdów:</li>
    łożyska, amortyzatory
                <li>układ hamulcowy:</li>
    klocki i tarcze hamulcowe
                <li>układy wydechowe:</li>
    tłumiki
                <li>przygotowanie do przeglądów technicznych</li>
                <li>drobne naprawy blacharskie</li>
                <li>sprzedaż opon samochodowych</li>
    pełna gama: opony osobowe, SUV, dostawcze, motocyklowe, quad
                <li>wymiana opon</li>
                <li>sprzedaż felg aluminiowych</li>
            </ul>
        </div></div>
        <div class='tab hidden' id='kursy'><div class='page-container'>
            <div class='route-buttons'>
            ";
        // line 141
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["trasy"]) || array_key_exists("trasy", $context) ? $context["trasy"] : (function () { throw new RuntimeError('Variable "trasy" does not exist.', 141, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["trasa"]) {
            // line 142
            echo "            <button class='route-button'>";
            echo twig_escape_filter($this->env, $context["trasa"], "html", null, true);
            echo "</button>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['trasa'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 144
        echo "            </div>
            <div class='routes'>
            ";
        // line 146
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["kursy"]) || array_key_exists("kursy", $context) ? $context["kursy"] : (function () { throw new RuntimeError('Variable "kursy" does not exist.', 146, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["kursyJednejTrasy"]) {
            // line 147
            echo "                <h3 class='route-title hidden'></h3>
                <div class='route-div hidden'>
                ";
            // line 149
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($context["kursyJednejTrasy"]);
            foreach ($context['_seq'] as $context["_key"] => $context["kurs"]) {
                // line 150
                echo "                <h3 class='course'>";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["kurs"], "czas", [], "any", false, false, false, 150), "html", null, true);
                echo "<span>";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["kurs"], "symbole", [], "any", false, false, false, 150), "html", null, true);
                echo "</span></h3>
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['kurs'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 152
            echo "                </div>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['kursyJednejTrasy'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 154
        echo "            </div>
            ";
        // line 155
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["trasy"]) || array_key_exists("trasy", $context) ? $context["trasy"] : (function () { throw new RuntimeError('Variable "trasy" does not exist.', 155, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["trasa"]) {
            // line 156
            echo "            <p class='route-legend hidden'>";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["trasa"], "legenda", [], "any", false, false, false, 156), "html", null, true);
            echo "</p>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['trasa'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 158
        echo "        </div></div>



        <div class='tab hidden' id='kontakt'><div class='page-container'>
            <div class='contact-wrapper'>
                <h3>Adres do korespondencji</h3>
                <p>70-326 Szczecin, Al. Piastów 75/7</p>
                <p>e-mail: biuro@transa.pl</p>
                <h3>Biuro</h3>
                <p>Stargard, ul. Dworcowa 9 pok. 113a (I piętro)</p>
                <p>Szczecin, ul. Dworcowa 20b (róg Św.Ducha i Nowa)</p>
                <h3>Bilety autokarowe online</h3>
                <p>e-mail: bilety@transa.pl</p>
                <button class='open-form-button'>NAPISZ DO NAS</button>
            </div>
        </div></div>



        <div class='tab hidden' id='certyfikaty'><div class='page-container'>
            <div class='certification-wrapper'>
                <div class='img-icon-wrapper'><h3>Polska</h3><img class='img-icon' src='/images/licencja.jpg'></img></div>
                <div class='img-icon-wrapper'><h3>EU</h3><img class='img-icon' src='/images/licencja_UE.jpg'></img></div>
            </div>
        </div></div>

    </div>
<img class='img-display hidden' src='/images/licencja.jpg'></img>
<img class='img-display hidden' src='/images/licencja_UE.jpg'></img>
    <div class='footer'>
        <p>Strona stworzona przez <a href='http://mateuszwojcieszak.com'>Mateusza Wojcieszaka</a> dla @Transa</p><a href='";
        // line 189
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("app_login");
        echo "'><button>Panel Administratora</button></a>
    </div>
</div>
</div>

<div class='contact-form hidden'>
    <div class='close-div'><i class='fa fa-times close-form-button'></i></div>
    <div class='input-div'>
        <div class='label'>Imię</div>
        <input type='text' id='name'>
    </div>
    <div class='input-div'>
        <div class='label'>E-mail</div>
        <input type='text' id='email'>
    </div>
    <div class='input-div'>
        <div class='label'>Nr tel.</div>
        <input type='text' id='phone'>
    </div>
    <div class='input-div'>
        <div class='label'>Liczba miejsc</div>
        <input type='text' id='seats'>
    </div>
    <div class='input-div'>
        <div class='label'>Miejsce podstawienia pojazdu</div>
        <input type='text' id='start'>
    </div>
    <div class='input-div'>
        <div class='label'>Miejsce docelowe</div>
        <input type='text' id='end'>
    </div>
    <div class='input-div'>
        <div class='label'>Informacje dodatkowe</div>
        <textarea type='text' id='message'></textarea>
    </div>
    <button class='send-contact' id='send-message'>Wyślij</button>
</div>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "main/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  324 => 189,  291 => 158,  282 => 156,  278 => 155,  275 => 154,  268 => 152,  257 => 150,  253 => 149,  249 => 147,  245 => 146,  241 => 144,  232 => 142,  228 => 141,  182 => 97,  173 => 94,  167 => 93,  164 => 92,  160 => 91,  73 => 6,  66 => 5,  53 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'front_base.html.twig' %}

{% block title %}Transa{% endblock %}

{% block body %}
<div class=\"site\">
<div class='bg'>




<div class='main-logo'><h1>Transa</h1><h4>Przewozy pasażerskie</h4></div>





<ul class='nav-list'>
    <li>
        <a href='#' class='nav-link'>
            <div class=\"icon\">
                <i class='fa fa-home' aria-hidden='true'></i>
                <i class='fa fa-home' aria-hidden='true'></i>
            </div>
            <div class=\"name\">
                <p>Nowości</p>
                <p>Nowości</p>
            </div>
        </a>
    </li>
    <li>
        <a href='#' class='nav-link'>
            <div class=\"icon\">
                <i class='fa fa-bus' aria-hidden='true'></i>
                <i class='fa fa-bus' aria-hidden='true'></i>
            </div>
            <div class=\"name\">
                <p>Oferta</p>
                <p>Oferta</p>
            </div>
        </a>
    </li>
    <li>
        <a href='#' class='nav-link'>
            <div class=\"icon\">
                <i class='fa fa-road' aria-hidden='true'></i>
                <i class='fa fa-road' aria-hidden='true'></i>
            </div>
            <div class=\"name\">
                <p>Rozkłady</p>
                <p>Rozkłady</p>
            </div>
        </a>
    </li>
    <li>
        <a href='#' class='nav-link'>
            <div class=\"icon\">
                <i class='fa fa-envelope' aria-hidden='true'></i>
                <i class='fa fa-envelope' aria-hidden='true'></i>
            </div>
            <div class=\"name\">
                <p>Kontakt</p>
                <p>Kontakt</p>
            </div>
        </a>
    </li>
    <li>
        <a href='#' class='nav-link'>
            <div class=\"icon\">
                <i class='fa fa-file' aria-hidden='true'></i>
                <i class='fa fa-file' aria-hidden='true'></i>
            </div>
            <div class=\"name\">
                <p>Certyfikaty</p>
                <p>Certyfikaty</p>
            </div>
        </a>
    </li>
</ul>





    <div class='tab-wrapper'>



        <div class='tab hidden' id='news'><div class='page-container'>
        <div class='news-wrapper'>
            {% for news in newsy %}
                <div class='post'>
                    <h3>{{ news.title }}<span>{{ news.time }}</span></h3>
                    <p>{{ news.message }}</p>
                </div>
            {% endfor %}
            </div>
        </div></div>



        <div class='tab hidden' id='oferta'><div class='page-container'>
            <h3>Wynajem pojazdów</h3>
                <p>Dysponujemy pojazdami <b>18, 20 i 55 miejscowymi</b>. Oferujemy wyjazdy dla grup na imprezy sportowe, kulturalne itp. Jeżeli potrzebują Państwo transportu osobowego, aby bezpiecznie i na czas dojechać tam gdzie zaplanowaliście to autobusy naszej firmy prowadzone przez doświadczonych i profesjonalnych kierowców, spełnią wszystkie Państwa oczekiwania.</p>
            <h3>Regularne linie</h3>
            <ul>
                <li>Szczecin - Stargard</li>
                <li>Szczecin - Pyrzyce</li>
                <li>Stargard - Pyrzyce</li>
                <li>Stargard - Brzezina</li>
                <li>Stargard - Żuków</li>
            </ul>
            <h3>Sprzedaż biletów autokarowych ONLINE</h3>
            <ul>
                <li>Przewody MIĘDZYNARODOWE</li>
                <li>Przewozy KRAJOWE</li>
                <li>Dowozy na LOTNISKO</li>
            </ul>
            <h3>Auto serwis</h3>
            <ul>
                <li>diagnostyka komputerowa</li>
                <li>mechanika pojazdowa</li>
                <li>obsługa:</li>
    filtry, oleje i płyny
                <li>zawieszenia pojazdów:</li>
    łożyska, amortyzatory
                <li>układ hamulcowy:</li>
    klocki i tarcze hamulcowe
                <li>układy wydechowe:</li>
    tłumiki
                <li>przygotowanie do przeglądów technicznych</li>
                <li>drobne naprawy blacharskie</li>
                <li>sprzedaż opon samochodowych</li>
    pełna gama: opony osobowe, SUV, dostawcze, motocyklowe, quad
                <li>wymiana opon</li>
                <li>sprzedaż felg aluminiowych</li>
            </ul>
        </div></div>
        <div class='tab hidden' id='kursy'><div class='page-container'>
            <div class='route-buttons'>
            {% for trasa in trasy %}
            <button class='route-button'>{{trasa}}</button>
            {% endfor %}
            </div>
            <div class='routes'>
            {% for kursyJednejTrasy in kursy %}
                <h3 class='route-title hidden'></h3>
                <div class='route-div hidden'>
                {% for kurs in kursyJednejTrasy %}
                <h3 class='course'>{{ kurs.czas }}<span>{{ kurs.symbole }}</span></h3>
                {% endfor %}
                </div>
            {% endfor %}
            </div>
            {% for trasa in trasy %}
            <p class='route-legend hidden'>{{trasa.legenda}}</p>
            {% endfor %}
        </div></div>



        <div class='tab hidden' id='kontakt'><div class='page-container'>
            <div class='contact-wrapper'>
                <h3>Adres do korespondencji</h3>
                <p>70-326 Szczecin, Al. Piastów 75/7</p>
                <p>e-mail: biuro@transa.pl</p>
                <h3>Biuro</h3>
                <p>Stargard, ul. Dworcowa 9 pok. 113a (I piętro)</p>
                <p>Szczecin, ul. Dworcowa 20b (róg Św.Ducha i Nowa)</p>
                <h3>Bilety autokarowe online</h3>
                <p>e-mail: bilety@transa.pl</p>
                <button class='open-form-button'>NAPISZ DO NAS</button>
            </div>
        </div></div>



        <div class='tab hidden' id='certyfikaty'><div class='page-container'>
            <div class='certification-wrapper'>
                <div class='img-icon-wrapper'><h3>Polska</h3><img class='img-icon' src='/images/licencja.jpg'></img></div>
                <div class='img-icon-wrapper'><h3>EU</h3><img class='img-icon' src='/images/licencja_UE.jpg'></img></div>
            </div>
        </div></div>

    </div>
<img class='img-display hidden' src='/images/licencja.jpg'></img>
<img class='img-display hidden' src='/images/licencja_UE.jpg'></img>
    <div class='footer'>
        <p>Strona stworzona przez <a href='http://mateuszwojcieszak.com'>Mateusza Wojcieszaka</a> dla @Transa</p><a href='{{ path('app_login') }}'><button>Panel Administratora</button></a>
    </div>
</div>
</div>

<div class='contact-form hidden'>
    <div class='close-div'><i class='fa fa-times close-form-button'></i></div>
    <div class='input-div'>
        <div class='label'>Imię</div>
        <input type='text' id='name'>
    </div>
    <div class='input-div'>
        <div class='label'>E-mail</div>
        <input type='text' id='email'>
    </div>
    <div class='input-div'>
        <div class='label'>Nr tel.</div>
        <input type='text' id='phone'>
    </div>
    <div class='input-div'>
        <div class='label'>Liczba miejsc</div>
        <input type='text' id='seats'>
    </div>
    <div class='input-div'>
        <div class='label'>Miejsce podstawienia pojazdu</div>
        <input type='text' id='start'>
    </div>
    <div class='input-div'>
        <div class='label'>Miejsce docelowe</div>
        <input type='text' id='end'>
    </div>
    <div class='input-div'>
        <div class='label'>Informacje dodatkowe</div>
        <textarea type='text' id='message'></textarea>
    </div>
    <button class='send-contact' id='send-message'>Wyślij</button>
</div>
{% endblock %}
", "main/index.html.twig", "C:\\xampp\\htdocs\\p5\\templates\\main\\index.html.twig");
    }
}
