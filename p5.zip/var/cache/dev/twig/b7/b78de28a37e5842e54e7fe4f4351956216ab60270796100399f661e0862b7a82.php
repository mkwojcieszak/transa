<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* admin/kursy.html.twig */
class __TwigTemplate_4b9005e9a92404726d98c1874b99ca8232f913efc69ed155fad719d20728a7ad extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
            'javascripts' => [$this, 'block_javascripts'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "admin_base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "admin/kursy.html.twig"));

        $this->parent = $this->loadTemplate("admin_base.html.twig", "admin/kursy.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <h2>Kursy na trasie ";
        echo twig_escape_filter($this->env, (isset($context["trasa"]) || array_key_exists("trasa", $context) ? $context["trasa"] : (function () { throw new RuntimeError('Variable "trasa" does not exist.', 4, $this->source); })()), "html", null, true);
        echo "</h2>
    <div class='kursy'>
    ";
        // line 6
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["kursy"]) || array_key_exists("kursy", $context) ? $context["kursy"] : (function () { throw new RuntimeError('Variable "kursy" does not exist.', 6, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["kurs"]) {
            // line 7
            echo "        <a href=\"";
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin.edytuj_kurs", ["id" => twig_get_attribute($this->env, $this->source, $context["kurs"], "id", [], "any", false, false, false, 7)]), "html", null, true);
            echo "\"><h3>";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["kurs"], "czas", [], "any", false, false, false, 7), "html", null, true);
            echo " <span>";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["kurs"], "symbole", [], "any", false, false, false, 7), "html", null, true);
            echo "</span></h3></a>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['kurs'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 9
        echo "    </div>
    <div class='route-legend'>
        ";
        // line 11
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["trasa"]) || array_key_exists("trasa", $context) ? $context["trasa"] : (function () { throw new RuntimeError('Variable "trasa" does not exist.', 11, $this->source); })()), "legenda", [], "any", false, false, false, 11), "html", null, true);
        echo "
    </div>
    <a href='";
        // line 13
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin.nowy_kurs", ["id" => twig_get_attribute($this->env, $this->source, (isset($context["trasa"]) || array_key_exists("trasa", $context) ? $context["trasa"] : (function () { throw new RuntimeError('Variable "trasa" does not exist.', 13, $this->source); })()), "id", [], "any", false, false, false, 13)]), "html", null, true);
        echo "'><button class='btn btn-primary'>Dodaj kurs</button></a>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 16
    public function block_javascripts($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        // line 17
        echo "    <script>
        const legenda = document.querySelector('.route-legend');
        legenda.innerHTML = legenda.innerHTML.replace(/(?:\\r\\n|\\r|\\n)/g, '<br />');
    </script>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "admin/kursy.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  108 => 17,  101 => 16,  92 => 13,  87 => 11,  83 => 9,  70 => 7,  66 => 6,  60 => 4,  53 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'admin_base.html.twig' %}

{% block body %}
    <h2>Kursy na trasie {{ trasa }}</h2>
    <div class='kursy'>
    {% for kurs in kursy %}
        <a href=\"{{ path('admin.edytuj_kurs', { id: kurs.id }) }}\"><h3>{{ kurs.czas }} <span>{{ kurs.symbole }}</span></h3></a>
    {% endfor %}
    </div>
    <div class='route-legend'>
        {{ trasa.legenda }}
    </div>
    <a href='{{ path('admin.nowy_kurs', { id: trasa.id }) }}'><button class='btn btn-primary'>Dodaj kurs</button></a>
{% endblock %}

{% block javascripts %}
    <script>
        const legenda = document.querySelector('.route-legend');
        legenda.innerHTML = legenda.innerHTML.replace(/(?:\\r\\n|\\r|\\n)/g, '<br />');
    </script>
{% endblock %}
", "admin/kursy.html.twig", "C:\\xampp\\htdocs\\p5\\templates\\admin\\kursy.html.twig");
    }
}
